
from setuptools import setup

setup(name='pyproblib',
      version='1.0',
      description='Probability Distribution Functions',
      packages=['pyproblib'],
      author='Saquib Mehmood',
      author_email='indowhales@protonmail.com',
      zip_safe=False)